/* 1. Define the WiFi credentials */
#define WIFI_SSID "ISD-Project-22Fall" // Network SSID (name)
#define WIFI_PASSWORD "isd@2022Fall" // Network password

/* 2. Define the API Key */
#define API_KEY "AIzaSyCWzx6g2Qmqdr-6lDt4pgjJJDBZBfAsFP0"

/* 3. Define the RTDB URL */
#define DATABASE_URL "https://isdn-2602-iot-default-rtdb.asia-southeast1.firebasedatabase.app/" //<databaseName>.firebaseio.com or <databaseName>.<region>.firebasedatabase.app

/* 4. Define the user Email and password that alreadey registerd or added in your project */
#define USER_EMAIL "Your Email"
#define USER_PASSWORD "Your Password"